from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QFileSystemModel, QListWidgetItem, QMessageBox, QFileDialog
from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtCore import QThread
import sys
import zipfile
import psutil
import shutil
import os
import requests
import json
import time
import aiohttp
import asyncio
import aiofiles
import multiprocessing
from lxml import html
import re
from uuid import uuid1
from minecraft_launcher_lib import *
from minecraft_launcher_lib.utils import get_minecraft_directory, get_version_list, get_installed_versions
from minecraft_launcher_lib.command import get_minecraft_command
from minecraft_launcher_lib.install import install_minecraft_version
import subprocess
from PIL import Image

with open("data/settings.json", "r", encoding="utf-8") as settings_read:
    load_gui_ = json.load(settings_read)
with open(f"interface/{load_gui_['settings']['interface']}/GUI_.py", "r", encoding="utf-8") as gui_selected_read:
    with open(f"interface/GUI_.py", "w", encoding="utf-8") as gui_selected_write:
        gui_selected_write.write(gui_selected_read.read())
from interface import GUI_
print(os.uname())


class CurseForge_(QThread):
    update_item_forge = QtCore.pyqtSignal(int)

    def __init__(self, mainwindows):
        QThread.__init__(self)
        self.mainwindows = mainwindows

    def run(self):
        clear_image = os.listdir("data/_icon_mods/")
        for clear_image_d in clear_image:
            os.remove(f"data/_icon_mods/{clear_image_d}")
        self.search_value_ = 10
        self.update_item_forge.emit(self.search_value_)
        headers = {
            'User-Agent': 'MJE/0.2.1',
            'Accept': 'application/json',
            'x-api-key': '$2a$10$r9HzNxN8dCbrin7zMjugUOsACZc1FDWU/FA3rkw6LxXpKcfJJaZI.'
        }

        if self.mainwindows.lineEdit.text() != "":
            r = requests.get('https://api.curseforge.com/v1/mods/search', params={
                'gameId': '432',
                'searchFilter': self.mainwindows.lineEdit.text(),
                'pageSize': self.mainwindows.comboBox_10.currentText()
            }, headers = headers)
        else:
            r = requests.get('https://api.curseforge.com/v1/mods/search', params={
                'gameId': '432',
                'pageSize': self.mainwindows.comboBox_10.currentText()
            }, headers = headers)

        if r != '':
            #search JSON
            with open("data/curseforge_.json", "w", encoding="utf-8") as json_w:
                json.dump(r.json(), json_w, indent=4)

            # with open("data/curseforge_.json", "w", encoding="utf-8") as json_w:
            #     json_w.write(r.text)

            multiprocessing.Process(target=self.start_search_mods(), name="search_mods").start()
            self.update_item_forge.emit(0)
        else:
            print("Error search_mod")

    def start_search_mods(self):
        async def download_icon(url_, name_img, name_, downloadCount_, fileLength_):
            item = QtWidgets.QListWidgetItem()
            mb_mod = fileLength_ // 1024
            if mb_mod > 1024:
                mb_mod = fileLength_ / 1024 / 1024
                mb_mod = f"{str(mb_mod).split('.')[0]}.{str(mb_mod).split('.')[-1][0]}MB"
            else:
                mb_mod = fileLength_ / 1024
                mb_mod = f"{str(mb_mod).split('.')[0]}.{str(mb_mod).split('.')[-1][0]}KB"
            item.setText(f"  {name_}\n\n  Download:{downloadCount_} | {mb_mod}")
            icon = QtGui.QIcon()
            icon.addPixmap(QtGui.QPixmap(f"res/icon/load_img.png"), QtGui.QIcon.Normal, QtGui.QIcon.On)
            item.setIcon(icon)
            self.mainwindows.listWidget_6.addItem(item)
            async with aiohttp.ClientSession() as session:
                async with session.get(url_, proxy=None, allow_redirects=True) as response:
                    async with aiofiles.open(f"data/_icon_mods/{name_img}", "wb") as while_img:
                        async for chunk in response.content.iter_chunked(64 * 1024):
                            await while_img.write(chunk)
            icon = QtGui.QIcon()
            icon.addPixmap(QtGui.QPixmap(f"data/_icon_mods/{name_img}"), QtGui.QIcon.Normal, QtGui.QIcon.On)
            item.setIcon(icon)
            self.search_value_ += self.value_progress_1
            self.update_item_forge.emit(self.search_value_)

        async def search_(self):
            try:
                json_data_mod = []
                with open("data/curseforge_.json", "r", encoding="utf-8") as json_r:
                    json_data_mod = json.load(json_r)

                self.mainwindows.listWidget_6.clear()
                num_item = 0
                for data_ in json_data_mod['data']:
                    if data_['logo']['url'] != "none":
                        num_item += 1
                self.value_progress_1 = 80 // num_item
                self.search_value_ = 20
                self.update_item_forge.emit(self.search_value_)
                
                tasks = []
                for data_ in json_data_mod['data']:
                    if data_['logo']['url'] != "none":
                        tasks.append(asyncio.create_task(download_icon(data_['logo']['url'], data_['logo']['title'], data_['name'], data_['downloadCount'], data_['latestFiles'][0]['fileLength'])))
                await asyncio.gather(*tasks)

            except Exception as e:
                print(f"error:{e}")


        multiprocessing.freeze_support()
        asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
        asyncio.run(search_(self))

class Import_modification(QThread):
    def __init__(self, mainwindows):
        QThread.__init__(self)
        self.mainwindows = mainwindows

    def run(self):
        try:
            os.makedirs("data/_temp")
        except:
            pass

        if self.mainwindows.import_mods_ == "mods":
            path_mod = self.mainwindows.path_mod
            name_mod = path_mod[0].split('/')[-1]
            print(path_mod[0])
            try:
                with zipfile.ZipFile(path_mod[0], "r") as read_jar_mod:
                    try: 
                        read_jar_mod.extractall("data/_temp")
                    except Exception as e:
                        print(e)

                file_zip = zipfile.ZipFile(f"data/mods/{name_mod}", "w")
                for folder, subfolders, files in os.walk("data/_temp"):
                    for file in files:
                        file_zip.write(os.path.join(folder, file),
                                       os.path.relpath(os.path.join(folder, file), "data/_temp"),
                                       compress_type=zipfile.ZIP_STORED)
                self.mainwindows.update_list_mods()

                try:
                    with open("data/_temp/mcmod.info", "r", encoding="utf-8") as info_mod_r:
                        with open(f"data/mods_info/info/{name_mod}.json", "w", encoding="utf-8") as info_mod_w:
                            info_mod_w.write(info_mod_r.read())
                except Exception as e:
                    with open("data/_temp/pack.mcmeta", "r", encoding="utf-8") as info_mod_r:
                        with open(f"data/mods_info/info/{name_mod}.json", "w", encoding="utf-8") as info_mod_w:
                            info_mod_w.write(info_mod_r.read())
                with open(f"data/mods_info/info/{name_mod}.json", "r", encoding="utf-8") as info_mod_j:
                    logo_save = json.load(info_mod_j)

                for list_file_logo in os.listdir("data/_temp"):
                    if list_file_logo.split('.')[-1] == "png":
                        size_ = (150, 150)
                        with Image.open(f"data/_temp/{list_file_logo}") as img:
                            img.thumbnail(size_)
                            img.save(f"data/mods_info/logo/{name_mod}.png")

                self.logo_mod = ""
                try:
                    for logo_ in logo_save:
                        self.logo_mod = logo_.get('logoFile')
                        if self.logo_mod:
                            size_ = (150, 150)
                            with Image.open(f"data/_temp/{self.logo_mod}") as img:
                                img.thumbnail(size_)
                                img.save(f"data/mods_info/logo/{name_mod}.png")
                except Exception as e:
                    self.logo_mod = logo_save.get('logoFile')
                    if self.logo_mod != None:
                        size_ = (150, 150)
                        with Image.open(f"data/_temp/{self.logo_mod}") as img:
                            img.thumbnail(size_)
                            img.save(f"data/mods_info/logo/{name_mod}.png")
            except Exception as e:
                pass

        if self.mainwindows.import_mods_ == "textures":
            path_mod = self.mainwindows.path_mod
            name_mod = path_mod[0].split('/')[-1]
            try:
                with zipfile.ZipFile(path_mod[0], "r") as read_jar_mod:
                    read_jar_mod.extractall("data/_temp")
                file_zip = zipfile.ZipFile(f"data/textures/{name_mod}", "w")
                for folder, subfolders, files in os.walk("data/_temp"):
                    for file in files:
                        file_zip.write(os.path.join(folder, file),
                                       os.path.relpath(os.path.join(folder, file), "data/_temp"),
                                       compress_type=zipfile.ZIP_STORED)
                self.mainwindows.update_list_texture()
                with open("data/_temp/pack.mcmeta", "r", encoding="utf-8") as info_mod_r:
                    with open(f"data/textures_info/info/{name_mod}.json", "w", encoding="utf-8") as info_mod_w:
                        info_mod_w.write(info_mod_r.read())
            except:
                pass

        if self.mainwindows.import_mods_ == "shaders":
            path_mod = self.mainwindows.path_mod
            name_mod = path_mod[0].split('/')[-1]
            try:
                with zipfile.ZipFile(path_mod[0], "r") as read_jar_mod:
                    read_jar_mod.extractall("data/_temp")
                file_zip = zipfile.ZipFile(f"data/shaders/{name_mod}", "w")
                for folder, subfolders, files in os.walk("data/_temp"):
                    for file in files:
                        file_zip.write(os.path.join(folder, file),
                                       os.path.relpath(os.path.join(folder, file), "data/_temp"),
                                       compress_type=zipfile.ZIP_STORED)
                self.mainwindows.update_list_texture()
            except:
                pass
        try:
            shutil.rmtree("data/_temp")
        except:
            try:
                shutil.rmtree("data/_temp")
            except:
                try:
                    error_time = f"data/error_{int(time.time())}_temp"
                    os.rename("data/_temp", error_time)
                    shutil.rmtree(error_time)
                except:
                    pass
        self.mainwindows.import_mods_ = None

class Game_s(QThread):
    info_update_start = QtCore.pyqtSignal(str, int)

    def __init__(self, mainwindows):
        QThread.__init__(self)
        self.mainwindows = mainwindows
        self.text_update_ = ""
        self.load_progress_ = 0

    def set_update_max(self, max_progressbar):
        self.mainwindows.progressBar.setMaximum(max_progressbar)
        self.info_update_start.emit(self.text_update_, self.load_progress_)

    def text_update(self, text_):
        self.text_update_ = text_
        self.info_update_start.emit(self.text_update_, self.load_progress_)

    def load_progress(self, value_load):
        self.load_progress_ = value_load
        self.info_update_start.emit(self.text_update_, self.load_progress_)


    def run(self):
        version_start = self.mainwindows.comboBox.currentText()
        RAM_ = 3000
        name_user = self.mainwindows.comboBox_2.currentText()
        minecraft_directory = ".minecraft"
        options = {
            'username': name_user,
            'uuid': str(uuid1()),
            'demo': False,
            'jvmArguments': [f"-Xmx{RAM_}M", f"-Xms{RAM_}M"]
        }
        self.info_update_start.emit("Starting", 100)
        try:
            subprocess.call(get_minecraft_command(version=version_start, minecraft_directory=minecraft_directory, options=options))
        except:
            try:
                install_minecraft_version(versionid=version_start, minecraft_directory=minecraft_directory, callback={'setStatus': self.text_update, 'setProgress': self.load_progress, 'setMax': self.set_update_max})
            except:
                print("ERROR install")
        self.info_update_start.emit("Play", 0)

class Version_info(QThread):
    info_ver = QtCore.pyqtSignal(str)

    def __init__(self, mainwindows):
        QThread.__init__(self)
        self.mainwindows = mainwindows

    def run(self):
        try:
            self.info_ver.emit("ok")
            for v_list in get_version_list():
                self.mainwindows.list_v.append(v_list)
        except:
            self.info_ver.emit("ERROR")

class ExampleApp(QtWidgets.QMainWindow, GUI_.Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)

        self.setWindowFlags(QtCore.Qt.FramelessWindowHint | self.windowFlags() & ~QtCore.Qt.WindowMaximizeButtonHint)
        self.show_w = False

        #Button
        self.pushButton_5.clicked.connect(self.close_)
        self.pushButton_7.clicked.connect(self.show_)
        self.pushButton_8.clicked.connect(self.show_winow_)
        self.pushButton_9.clicked.connect(self.start_game)
        self.pushButton_26.clicked.connect(self.add_version)
        self.pushButton_4.clicked.connect(self.cancel_add)
        self.pushButton_25.clicked.connect(self.del_version)
        self.pushButton_6.clicked.connect(self.del_version_continue)
        self.pushButton_32.clicked.connect(self.save_mod)
        self.pushButton_33.clicked.connect(self.save_textures)
        self.pushButton_36.clicked.connect(self.save_shaders)
        self.pushButton.clicked.connect(self.search_mod)
        self.pushButton_18.clicked.connect(self.create_user_name)
        self.pushButton_41.clicked.connect(self.create_user_name_exit)
        self.pushButton_43.clicked.connect(self.create_user_name_save)
        self.pushButton_42.clicked.connect(self.create_user_name_icon)
        self.pushButton_22.clicked.connect(self.settings_save)

        #ComboBox
        self.comboBox_11.currentTextChanged.connect(self.update_ver)

        #ListWidget
        self.listWidget_7.clicked.connect(self.add_version_list)
        self.listWidget_3.clicked.connect(self.mods_info_)

        #hide
        self.pushButton_6.hide()
        self.label_12.hide()
        self.progressBar_2.hide()

        #QThread
        self.game_start = Game_s(mainwindows=self)
        self.game_start.info_update_start.connect(self.info_start)
        self.ver_list = Version_info(mainwindows=self)
        self.ver_list.info_ver.connect(self.update_ver)
        self.import_mod = Import_modification(mainwindows=self)
        self.search_forge = CurseForge_(mainwindows=self)
        self.search_forge.update_item_forge.connect(self.item_forge_list)


        self.set_user()
        self.version_m()
        self.show_()
        self.update_list_mods()
        self.update_list_texture()

        #info
        self.import_mods_ = None

    def settings_save(self):
        with open("data/settings.json", "r", encoding="utf-8") as settings_r:
            settings_d = json.load(settings_r)

        save_close_launcher = self.radioButton_11.isChecked()
        save_interface = self.comboBox_3.currentText()
        save_themes = self.comboBox_12.currentText()
        save_background_by_date = self.radioButton_12.isChecked()
        save_custom_background = self.lineEdit_2.text()
        save_folder = self.lineEdit_3.text()
        save_resolution_x = self.spinBox_3.value()
        save_resolution_y = self.spinBox_4.value()
        save_full_screen_mode = self.checkBox_5.isChecked()
        save_ram_allocation = self.spinBox_5.value()
        save_ram_allocation_slider = self.horizontalSlider.value()
        save_arguments_0 = self.lineEdit_4.text()
        save_arguments_1 = self.lineEdit_5.text()

        settings = {
                "settings": {
                    "close_launcher": save_close_launcher,
                    "interface": save_interface,
                    "themes": save_themes,
                    "background_by_date": save_background_by_date,
                    "custom_background": save_custom_background,
                    "color-0:": "",
                    "color-1:": "",
                    "color-2:": "",
                    "color-3:": "",
                    "folder": save_folder,
                    "resolution_x": save_resolution_x,
                    "resolution_y": save_resolution_y,
                    "full_screen_mode": save_full_screen_mode,
                    "ram_allocation": save_ram_allocation,
                    "arguments_0": save_arguments_0,
                    "arguments_1": save_arguments_1
                },
                "gui": {
                    "name": settings_d['gui']['name'],
                    "mc_version": settings_d['gui']['mc_version']
                }
            }

        with open("data/settings.json", "w", encoding="utf-8") as settings_w:
            json.dump(settings, settings_w, ensure_ascii=False, indent=4)

    def settings_load(self):
        pass

    def create_user_name_icon(self):
        try:
            path_icon = QFileDialog.getOpenFileName(self, "Select mod", ".", "*.png *.jpg *.gif *.ico")
            self.m_icon = path_icon[0].split('/')[-1]
            if path_icon[0]:
                with open(path_icon[0], "rb") as read_icon_user:
                    with open(f"res/user_{self.m_icon}", "wb") as write_icon_user:
                        write_icon_user.write(read_icon_user.read())
                icon = QtGui.QIcon()
                icon.addPixmap(QtGui.QPixmap(f"res/user_{self.m_icon}"), QtGui.QIcon.Normal, QtGui.QIcon.On)
                self.pushButton_42.setIcon(icon)
        except:
            pass

    def create_user_name_save(self):
        if self.lineEdit_6.text() != "":
            with open("data/user.json", "r", encoding="utf-8") as users_load_json:
                users_load_ = json.load(users_load_json)
            users_new = {
                "name": self.lineEdit_6.text(),
                "password": "",
                "icon": f"user_{self.m_icon}"
            }
            users_load_.append(users_new)
            with open("data/user.json", "w", encoding="utf-8") as users_save_json:
                json.dump(users_load_, users_save_json, ensure_ascii=False, indent=4)
            self.set_user()
            self.stackedWidget_3.setCurrentIndex(0)

    def create_user_name_exit(self):
        self.stackedWidget_3.setCurrentIndex(0)

    def create_user_name(self):
        self.m_icon = False
        self.stackedWidget_3.setCurrentIndex(1)

    def item_forge_list(self, value_):
        self.progressBar_2.setValue(value_)
        if value_ == 0:
            self.progressBar_2.hide()

    def search_mod(self):
        self.progressBar_2.show()
        self.search_forge.start()

    def mods_info_(self):
        try:
            self.mods_info_read = []
            with open(f"data/mods_info/info/{self.listWidget_3.currentItem().text()}.json", "r", encoding="utf-8") as read_info_m:
                self.mods_info_read = json.load(read_info_m)

            for mods_info_r in self.mods_info_read:
                text_h_ = mods_info_r.get('modid')
                text_h_0 = mods_info_r.get('name')
                text_h_1 = mods_info_r.get('version')
                text_h_2 = mods_info_r.get('mcversion')
                text_h_3 = mods_info_r.get('description')
                text_h_4 = ""
                img_html = ""
                try:
                    with open(f"data/mods_info/logo/{self.listWidget_3.currentItem().text()}.png", "rb") as check_logo:
                        check_logo.read()
                    img_html = f"""<img src="data/mods_info/logo/{self.listWidget_3.currentItem().text()}.png" />"""
                except:
                    pass
                if mods_info_r.get('authorList') != None:
                    for author_ in mods_info_r.get('authorList'):
                        text_h_4 += f"| {author_} "
                    text_h_4 += "|"
                else:
                    text_h_4 = "none"

                self.textBrowser.setText(f"""<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
                <html><head><meta name="qrichtext" content="1" /><style type="text/css">
                </style></head><body style=" font-family:'Terminal'; font-size:8.25pt; font-weight:400; font-style:normal;">
                <p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{img_html}</p><br />
                <p align="center" style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600;"></p>
                <p align="center" style=" font-size:14pt; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{text_h_0}</p><br />
                <p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">version: {text_h_1}<br />modid: {text_h_0}<br />mcversion: {text_h_2}<br /><br />description: {text_h_3}<br /><br />authorList: {text_h_4}</span></p></body></html>""")
        except:
            try:
                text_h_ = self.mods_info_read.get('modid')
                text_h_0 = self.mods_info_read.get('name')
                text_h_1 = self.mods_info_read.get('version')
                text_h_2 = self.mods_info_read.get('mcversion')
                text_h_3 = self.mods_info_read.get('description')
                text_h_4 = ""
                img_html = ""
                try:
                    with open(f"data/mods_info/logo/{self.listWidget_3.currentItem().text()}.png", "rb") as check_logo:
                        check_logo.read()
                    img_html = f"""<img src="data/mods_info/logo/{self.listWidget_3.currentItem().text()}.png" />"""
                except:
                    pass
                if self.mods_info_read.get('authorList') != None:
                    for author_ in self.mods_info_read.get('authorList'):
                        text_h_4 += f"| {author_} "
                    text_h_4 += "|"
                else:
                    text_h_4 = "none"

                self.textBrowser.setText(f"""<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0//EN" "http://www.w3.org/TR/REC-html40/strict.dtd">
                <html><head><meta name="qrichtext" content="1" /><style type="text/css">
                </style></head><body style=" font-family:'Terminal'; font-size:8.25pt; font-weight:400; font-style:normal;">
                <p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{img_html}</p><br />
                <p align="center" style="-qt-paragraph-type:empty; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600;"></p>
                <p align="center" style=" font-size:14pt; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;">{text_h_0}</p><br />
                <p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600;">version: {text_h_1}<br />modid: {text_h_0}<br />mcversion: {text_h_2}<br /><br />description: {text_h_3}<br /><br />authorList: {text_h_4}</span></p></body></html>""")
            except:
                self.textBrowser.setText(f"""<p align="center" style=" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;"><span style=" font-weight:600; font-size:14pt;">None</span></p>""")

    def update_list_texture(self):
        self.listWidget_4.clear()
        update_ = os.listdir("data/textures")
        for texture_list in update_:
            self.listWidget_4.addItem(texture_list)

    def update_list_mods(self):
        self.listWidget_3.clear()
        update_ = os.listdir("data/mods")
        for mod_list in update_:
            self.listWidget_3.addItem(mod_list)

    def update_list_shaders(self):
        self.listWidget_5.clear()
        update_ = os.listdir("data/shaders")
        for shader_list in update_:
            self.listWidget_5.addItem(shader_list)

    def save_mod(self):
        if self.import_mods_ == None:
            self.path_mod = QFileDialog.getOpenFileName(self, "Select mod", ".", "*.jar")
            if self.path_mod[0] != "":
                self.import_mods_ = "mods"
                self.import_mod.start()

    def save_textures(self):
        if self.import_mods_ == None:
            self.path_mod = QFileDialog.getOpenFileName(self, "Select textures", ".")
            if self.path_mod[0] != "":
                self.import_mods_ = "textures"
                self.import_mod.start()

    def save_shaders(self):
        if self.import_mods_ == None:
            self.path_mod = QFileDialog.getOpenFileName(self, "Select shaders", ".")
            if self.path_mod[0] != "":
                self.import_mods_ = "shaders"
                self.import_mod.start()

    def set_user(self):
        self.comboBox_2.clear()
        self.comboBox_6.clear()
        with open("data/user.json", "r", encoding="utf-8") as user_read:
            user_json = json.load(user_read)
        for user_name in user_json:
            if user_name['icon'] != False:
                icon3 = QtGui.QIcon()
                icon3.addPixmap(QtGui.QPixmap(f"res/{user_name['icon']}"), QtGui.QIcon.Normal, QtGui.QIcon.On)
                self.comboBox_2.addItem(icon3, user_name['name'])
                self.comboBox_6.addItem(icon3, user_name['name'])
            else:
                self.comboBox_6.addItem(user_name['name'])
                self.comboBox_2.addItem(user_name['name'])

    def del_version_continue(self):
        try:
            shutil.rmtree(f".minecraft/versions/{self.listWidget_2.currentItem().text()}")
        except:
            pass
        self.pushButton_6.hide()
        self.version_m()

    def del_version(self):
        self.pushButton_6.show()

    def add_version_list(self):
        self.stackedWidget_2.setCurrentIndex(0)
        self.listWidget_2.addItem(self.listWidget_7.currentItem().text())
        self.comboBox.addItem(self.listWidget_7.currentItem().text())

    def update_ver(self, info_):
        self.listWidget_7.clear()
        if info_ != "ERROR":
            for list_ in self.list_v:
                if list_['type'] == self.comboBox_11.currentText():
                    self.listWidget_7.addItem(list_['id'])
                if self.comboBox_11.currentText() == "all":
                    self.listWidget_7.addItem(list_['id'])
        else:
            self.mainwindows.label_12.show()

    def cancel_add(self):
        self.stackedWidget_2.setCurrentIndex(0)

    def add_version(self):
        self.stackedWidget_2.setCurrentIndex(1)
        self.list_v = []
        self.ver_list.start()

    def version_m(self):
        self.comboBox.clear()
        self.listWidget_2.clear()
        for version in get_installed_versions(minecraft_directory=".minecraft"):
            self.comboBox.addItem(version["id"])
            self.listWidget_2.addItem(version["id"])

    def mousePressEvent(self, event):
        try:
            if self.show_w == True:
                if event.button() == QtCore.Qt.LeftButton:
                    self.old_pos = event.pos()
        except:
            pass

    def mouseReleaseEvent(self, event):
        try:
            if self.show_w == True:
                if event.button() == QtCore.Qt.LeftButton:
                    self.old_pos = None
        except:
            pass

    def mouseMoveEvent(self, event):
        try:
            if self.show_w == True:
                if not self.old_pos:
                    return
                delta = event.pos() - self.old_pos
                self.move(self.pos() + delta)
        except:
            pass

    def close_(self):
        sys.exit()

    def show_(self):
        if self.show_w == True:
            self.showMaximized()
            self.show_w = False
        else:
            self.showNormal()
            self.show_w = True

    def show_winow_(self):
        self.showMinimized()

    def info_start(self, text_, value_):
        self.pushButton_9.setText(text_)
        self.progressBar.setValue(value_)
        if text_ == "Play":
            self.pushButton_9.setStyleSheet("QPushButton {\n"
            "    background-color: rgb(241, 100, 54);\n"
            "    border: 3px solid rgb(201, 80, 34);\n"
            "    border-radius: 0px;\n"
            "}\n"
            "QPushButton:hover {\n"
            "    background-color: rgb(252, 120, 74);\n"
            "    border: 3px solid rgb(208, 90, 44);\n"
            "}\n"
            "QPushButton:pressed {\n"
            "    background-color: rgb(255, 130, 74);\n"
            "    border: 3px solid rgb(211, 100, 54);\n"
            "}")
            self.pushButton_9.setEnabled(True)

    def start_game(self):
        self.pushButton_9.setEnabled(False)
        self.pushButton_9.setStyleSheet("QPushButton {\n"
        "    background-color: rgb(63, 65, 70);\n"
        "    border: 3px solid rgb(83, 85, 90);\n"
        "    border-radius: 0px;\n"
        "}\n"
        "QPushButton:hover {\n"
        "    background-color: rgb(63, 65, 70);\n"
        "    border: 3px solid rgb(83, 85, 90);\n"
        "}\n"
        "QPushButton:pressed {\n"
        "    background-color: rgb(63, 65, 70);\n"
        "    border: 3px solid rgb(83, 85, 90);\n"
        "}")
        self.game_start.start()

def main():
    app = QtWidgets.QApplication(sys.argv)
    window = ExampleApp()
    window.show()
    app.exec_()
    
if __name__ == '__main__':
    main()